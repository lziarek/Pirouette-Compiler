type State = Map String String
data Request = Put String String | Get String
type Response = Maybe String

kvs :: Request @ "client"
-> IORef State @ "server"
-> Choreo IO (Response @ "client")
kvs request state = do
request' <- (client, request) ~> server
1response <- server `locally` \un -> handleRequest (un request') (un state)
(server, response) ~> client

handleRequest :: Request -> IORef State -> IO Response
handleRequest request state = case request of
Put key value -> do
modifyIORef state (Map.insert key value)
return (Just value)
Get key -> do
state <- readIORef state
return (Map.lookup key state)

mainChoreo :: Choreo IO ()
mainChoreo = do
state <- server `locally` \_ -> newIORef Map.empty
loop state
where
loop :: IORef State @ "server" -> Choreo IO ()
loop state = do
request <- client `locally` \_ -> readRequest
response <- kvs request state
client `locally` \un -> do putStrLn ("> " ++ show (un response))
loop state